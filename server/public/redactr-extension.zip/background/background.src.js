/**
 * MV3 service worker — bundled via esbuild (see ../package.json's
 * build:background script) because it now imports the Firebase modular
 * SDK, which can't be loaded as a plain classic script.
 *
 * Responsibilities:
 *  1. Cross-tab state — "leaks prevented" counter, Tier-1 on/off, Tier-2
 *     on/off + model status, and now auth state — all in
 *     chrome.storage.local so the popup and content scripts stay in sync.
 *  2. Bridge content scripts to the offscreen document hosting the Tier-2
 *     NER pipeline (unchanged from before).
 *  3. Google sign-in (via chrome.identity.launchWebAuthFlow + Firebase
 *     Auth — chosen over chrome.identity.getAuthToken because it behaves
 *     identically in Chrome and Edge, both required per the project spec)
 *     and syncing blocked-prompt METADATA (never the raw secret text) to
 *     Firestore via the Redactr API's /createAlert route.
 */
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithCredential, signOut as firebaseSignOut } from "firebase/auth/web-extension";

const FIREBASE_CONFIG = {
  apiKey: "AIzaSyBTg49GkhytsgHECw-_SagfU_TIV57ncck",
  authDomain: "redactr-ea568.firebaseapp.com",
  projectId: "redactr-ea568",
  appId: "1:116258256150:web:b407a3c35fabc82c0a4c37",
};

// Web-application OAuth Client ID (reused the one Firebase auto-created),
// with chrome.identity.getRedirectURL() registered as an authorized
// redirect URI for this extension's ID.
const GOOGLE_OAUTH_CLIENT_ID = "116258256150-bk6aec5oadquj8hioc1qac1092nbar50.apps.googleusercontent.com";

// See server/index.js — this replaced the Cloud Functions (which needed
// the Blaze billing plan), hosted on Render.
const API_BASE_URL = "https://redactr-ln5t.onrender.com";

const app = initializeApp(FIREBASE_CONFIG);
const auth = getAuth(app);

/** Calls a route on the Express API with a Firebase ID token attached.
 *  Each attempt has a 25 s AbortController timeout so a Render cold-start
 *  never hangs the service worker indefinitely. Retries immediately (no
 *  sleep — sleep/setTimeout doesn't keep MV3 service workers alive) when
 *  the server returns HTML instead of JSON. */
async function callApi(method, path, body, _retry = 0) {
  if (!auth.currentUser) throw new Error("Not signed in.");
  const idToken = await auth.currentUser.getIdToken();

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 25_000);

  let response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, {
      method,
      signal: controller.signal,
      headers: {
        Authorization: `Bearer ${idToken}`,
        "Content-Type": "application/json",
      },
      body: body ? JSON.stringify(body) : undefined,
    });
  } finally {
    clearTimeout(timeoutId);
  }

  let data;
  try {
    data = await response.json();
  } catch (_) {
    // Render returned HTML (cold-starting) — retry immediately, no sleep.
    if (_retry < 4) return callApi(method, path, body, _retry + 1);
    throw new Error("Server unavailable — please try again in a moment.");
  }

  if (!response.ok) {
    throw new Error(data.error || `Request failed (${response.status})`);
  }
  return data;
}

const DEFAULT_STATE = {
  enabled: true,
  leaksPrevented: 0,
  tier2Enabled: false,
  tier2Status: "idle", // idle | loading | ready | error
  authUser: null, // { uid, email, displayName, photoURL } | null
  tier2Allowed: false, // entitlement: only true on the Enterprise plan (see getEntitlement)
  plan: null,
  role: null, // "admin" | "employee" | null — used by scanner.js to suppress approval button for admins
  companyName: null, // set after successful company join — shown in popup plan badge
  joinError: null, // set when signed in but no invite exists for this email yet
  customKeywords: [], // Enterprise-only, admin-managed (see getEntitlement)
  customEntities: [], // Enterprise-only GLiNER labels (see getEntitlement + addCustomEntity)
  trialDaysLeft: 0,
  trialExpired: false,
  // Enterprise file scanning
  fileInterceptEnabled: false,
  fileInterceptAllowed: false, // true when plan === "enterprise"
  filesBlocked: 0,
};

const OFFSCREEN_PATH = "offscreen/offscreen.html";
let creatingOffscreenDocument = null;

chrome.runtime.onInstalled.addListener(async () => {
  const current = await chrome.storage.local.get(DEFAULT_STATE);
  await chrome.storage.local.set(current);
  chrome.alarms.create("keepAlive", { periodInMinutes: 14 });
});

// ── Tier-2 warmup with automatic retry / polling ──────────────────────────────
// _warmupRetries resets on service-worker restart (module-level), which is fine:
// each wake recreates the alarm and retries from scratch.
let _warmupRetries = 0;
const MAX_WARMUP_RETRIES = 10; // ~10 minutes before giving up

async function attemptWarmup() {
  const { tier2Enabled } = await chrome.storage.local.get({ tier2Enabled: false });
  if (!tier2Enabled) {
    chrome.alarms.clear("pollTier2");
    return;
  }
  try {
    const data = await callApi("POST", "/nerWarmup");
    // Server returned 200 — user is on an entitled plan (server 403s otherwise).
    await chrome.storage.local.set({ tier2Allowed: true });
    _warmupRetries = 0;
    if (data.status === "ready") {
      await chrome.storage.local.set({ tier2Status: "ready" });
      chrome.alarms.clear("pollTier2");
    } else {
      // Model is loading server-side — poll again in 1 minute.
      await chrome.storage.local.set({ tier2Status: "loading" });
      chrome.alarms.create("pollTier2", { delayInMinutes: 1 });
    }
  } catch (error) {
    _warmupRetries++;
    console.warn(`Redactr: Tier-2 warmup attempt ${_warmupRetries} failed:`, error.message);
    if (_warmupRetries >= MAX_WARMUP_RETRIES) {
      await chrome.storage.local.set({ tier2Status: "error" });
      chrome.alarms.clear("pollTier2");
      _warmupRetries = 0;
    } else {
      // Render cold-starting or offline — keep "loading" and retry in 1 minute.
      await chrome.storage.local.set({ tier2Status: "loading" });
      chrome.alarms.create("pollTier2", { delayInMinutes: 1 });
    }
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "keepAlive") {
    fetch(`${API_BASE_URL}/ping`).catch(() => {});
  }
  if (alarm.name === "pollTier2") {
    attemptWarmup();
  }
});

auth.onAuthStateChanged((user) => {
  chrome.storage.local.set({
    authUser: user ? { uid: user.uid, email: user.email, displayName: user.displayName, photoURL: user.photoURL } : null,
  });

  if (user) {
    joinCompany();
  } else {
    chrome.alarms.clear("pollTier2");
    chrome.storage.local.set({
      tier2Allowed: false,
      tier2Status: "idle",
      plan: null,
      role: null,
      companyName: null,
      joinError: null,
      leaksPrevented: 0,
      filesBlocked: 0,
      fileInterceptAllowed: false,
      trialDaysLeft: 0,
      trialExpired: false,
      customEntities: [],
    });
  }
});

/**
 * Called once after sign-in (and on every service-worker wake while signed
 * in — cheap, and the server already short-circuits once users/{uid}
 * exists). The extension only ever JOINS via an existing invite — it never
 * sends a companyName, unlike the app's CompanySetupScreen — so a random
 * sign-in here can't spin up a new company. If there's no invite waiting
 * yet, the server returns a clear 400 that gets surfaced in the popup
 * instead of silently leaving Tier-1/Tier-2 half-linked.
 */
async function joinCompany() {
  try {
    const data = await callApi("POST", "/claimOrJoinCompany");
    if (data.role) await chrome.storage.local.set({ role: data.role });
    await chrome.storage.local.set({ joinError: null });
  } catch (error) {
    // Trial users have no company invite — claimOrJoinCompany returns 400,
    // but we still need to fetch their entitlement (which will hit the
    // trials/{uid} path on the server). Non-trial 400s surface as joinError.
    await chrome.storage.local.set({ joinError: String(error.message || error) });
  }
  // Always fetch entitlement regardless — trial users bypass company join.
  await fetchEntitlement();
}

/**
 * Never trusts a long-lived client cache for something that gates a paid
 * feature.
 */
async function fetchEntitlement() {
  try {
    const data = await callApi("GET", "/getEntitlement");
    await chrome.storage.local.set({
      plan: data.plan,
      role: data.role ?? null,
      companyName: data.companyName ?? null,
      tier2Allowed: data.tier2Allowed,
      customKeywords: data.customKeywords ?? [],
      customEntities: data.customEntities ?? [],
      trialDaysLeft: data.trialDaysLeft ?? 0,
      trialExpired: data.trialExpired ?? false,
      // File-intercept is exclusive to Enterprise
      fileInterceptAllowed: data.plan === "enterprise",
    });
    if (data.plan === "trial" || data.plan === "trial_expired") {
      await chrome.storage.local.set({ joinError: null });
    }
    // If the user already had Tier-2 toggled on (persisted across service-worker
    // restarts), resume warmup now that entitlement is confirmed.
    if (data.tier2Allowed) {
      const { tier2Enabled } = await chrome.storage.local.get({ tier2Enabled: false });
      if (tier2Enabled) {
        _warmupRetries = 0;
        attemptWarmup();
      }
    }
  } catch (error) {
    console.warn("Redactr: failed to fetch entitlement", error);
  }
}

function buildGoogleAuthUrl(redirectUri, nonce) {
  const params = new URLSearchParams({
    client_id: GOOGLE_OAUTH_CLIENT_ID,
    response_type: "id_token",
    redirect_uri: redirectUri,
    scope: "openid email profile",
    prompt: "select_account",
    nonce,
  });
  return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
}

async function signInWithGoogle() {
  const redirectUri = chrome.identity.getRedirectURL();
  const nonce = crypto.randomUUID();
  const authUrl = buildGoogleAuthUrl(redirectUri, nonce);

  const responseUrl = await chrome.identity.launchWebAuthFlow({ url: authUrl, interactive: true });
  if (!responseUrl) throw new Error("Sign-in was cancelled.");

  const fragment = new URL(responseUrl).hash.slice(1);
  const idToken = new URLSearchParams(fragment).get("id_token");
  if (!idToken) throw new Error("Google did not return an id_token.");

  const credential = GoogleAuthProvider.credential(idToken);
  const userCredential = await signInWithCredential(auth, credential);
  return userCredential.user;
}

async function signOutOfGoogle() {
  await firebaseSignOut(auth);
}

/**
 * Sends only metadata about a blocked prompt — finding types, the
 * aggregate score, and which site it happened on — never the matched
 * secret text. No-ops silently if not signed in (local counter already
 * covers the offline/signed-out case).
 */
/**
 * Creates an alert on the server and returns the alertId so the content
 * script can poll /alertStatus/:alertId for the manager's decision.
 * Returns null when not signed in or the call fails (fail-open).
 */
async function syncAlert({ findingTypes, riskScore, site, tier, source, overridden }, _isRetry = false) {
  if (!auth.currentUser) return null;
  try {
    const data = await callApi("POST", "/createAlert", {
      findingTypes, riskScore, site, tier,
      source: source ?? "prompt",
      overridden: overridden ?? false,
    });
    return data?.alertId ?? null;
  } catch (error) {
    // If the server says the user isn't set up yet, attempt join then retry once.
    if (!_isRetry && error.message?.includes("company setup")) {
      try { await joinCompany(); } catch (_) {}
      return syncAlert({ findingTypes, riskScore, site, tier, source, overridden }, true);
    }
    console.warn("Redactr: failed to sync alert to backend", error.message);
    return null;
  }
}

async function ensureOffscreenDocument() {
  const existing = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  if (existing.length > 0) return;

  if (creatingOffscreenDocument) {
    await creatingOffscreenDocument;
    return;
  }

  creatingOffscreenDocument = chrome.offscreen.createDocument({
    url: OFFSCREEN_PATH,
    reasons: ["WORKERS"],
    justification: "Performs local pixel analysis of images in file upload inputs using OffscreenCanvas to detect embedded sensitive content.",
  });

  try {
    await creatingOffscreenDocument;
  } finally {
    creatingOffscreenDocument = null;
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "LEAK_BLOCKED") {
    (async () => {
      const { leaksPrevented } = await chrome.storage.local.get({ leaksPrevented: 0 });
      const next = leaksPrevented + 1;
      await chrome.storage.local.set({ leaksPrevented: next });
      // Await alert creation so the alertId is available for approval polling.
      const alertId = message.metadata ? await syncAlert(message.metadata) : null;
      sendResponse({ leaksPrevented: next, alertId });
    })();
    return true;
  }

  /* ── Employee requested approval: poll its status ────────────────────── */
  if (message?.type === "POLL_ALERT_STATUS") {
    (async () => {
      if (!auth.currentUser) {
        sendResponse({ ok: false, error: "not_signed_in" });
        return;
      }
      try {
        const data = await callApi("GET", `/alertStatus/${message.alertId}`);
        sendResponse({ ok: true, status: data.status });
      } catch (error) {
        sendResponse({ ok: false, error: String(error) });
      }
    })();
    return true;
  }

  /* ── Enterprise file scanning — file/email blocked ──────────────────── */
  if (message?.type === "FILE_BLOCKED") {
    (async () => {
      const { filesBlocked } = await chrome.storage.local.get({ filesBlocked: 0 });
      const next = filesBlocked + 1;
      await chrome.storage.local.set({ filesBlocked: next });
      sendResponse({ filesBlocked: next });

      if (message.metadata) {
        syncAlert(message.metadata);
      }
    })();
    return true;
  }

  /* ── Employee overrode a file block — log separately for admin audit ── */
  if (message?.type === "FILE_OVERRIDE") {
    (async () => {
      if (message.metadata) {
        syncAlert({ ...message.metadata, overridden: true });
      }
      sendResponse({ ok: true });
    })();
    return true;
  }

  /* ── Enterprise file scanning — image analysis via offscreen canvas ──── */
  if (message?.type === "FILE_SCAN_IMAGE") {
    (async () => {
      const { fileInterceptAllowed } = await chrome.storage.local.get({ fileInterceptAllowed: false });
      if (!fileInterceptAllowed) {
        sendResponse({ ok: true, blocked: false });
        return;
      }
      try {
        await ensureOffscreenDocument();
        const response = await chrome.runtime.sendMessage({
          target  : "offscreen",
          type    : "FILE_SCAN_IMAGE",
          dataUrl : message.dataUrl,
        });
        sendResponse(response);
      } catch (error) {
        // Fail open — never block an image because the offscreen had an error
        sendResponse({ ok: true, blocked: false, error: String(error) });
      }
    })();
    return true;
  }

  if (message?.type === "GET_STATE") {
    chrome.storage.local.get(DEFAULT_STATE).then((state) => sendResponse(state));
    return true;
  }

  if (message?.type === "SIGN_IN") {
    signInWithGoogle()
      .then((user) => sendResponse({ ok: true, user: { email: user.email, displayName: user.displayName } }))
      .catch((error) => sendResponse({ ok: false, error: String(error) }));
    return true;
  }

  if (message?.type === "SIGN_OUT") {
    signOutOfGoogle()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: String(error) }));
    return true;
  }

  if (message?.type === "RETRY_JOIN") {
    (async () => {
      try {
        await joinCompany();
        sendResponse({ ok: true });
      } catch (error) {
        sendResponse({ ok: false, error: String(error) });
      }
    })();
    return true;
  }

  if (message?.target === "background" && message.type === "TIER2_PROGRESS") {
    const status = message.progress?.status === "ready" ? "ready" : "loading";
    chrome.storage.local.set({ tier2Status: status });
    return false;
  }

  if (message?.target === "background" && message.type === "TIER2_SCAN") {
    (async () => {
      const { tier2Enabled, customEntities } = await chrome.storage.local.get({
        tier2Enabled: false,
        customEntities: [],
      });
      // tier2Allowed gate removed — server enforces entitlement on /nerScan.
      // Removing it here means Tier-2 works even when fetchEntitlement failed on cold start.
      if (!tier2Enabled) {
        sendResponse({ ok: false, error: "tier2_disabled" });
        return;
      }
      try {
        const data = await callApi("POST", "/nerScan", {
          text: message.text,
          labels: customEntities,
        });
        await chrome.storage.local.set({ tier2Status: "ready" });
        sendResponse({ ok: true, entities: data.entities ?? [] });
      } catch (error) {
        // Fail-open: Tier-1 result used unchanged if NER fails.
        sendResponse({ ok: false, error: String(error), entities: [] });
      }
    })();
    return true;
  }

  if (message?.type === "TIER2_WARMUP") {
    (async () => {
      // No tier2Allowed gate — let the server confirm entitlement.
      // attemptWarmup() sets tier2Allowed: true when server returns 200,
      // so the popup toggle unlocks even if fetchEntitlement failed on cold start.
      _warmupRetries = 0;
      await chrome.storage.local.set({ tier2Status: "loading" });
      await attemptWarmup();
      sendResponse({ ok: true });
    })();
    return true;
  }
});
